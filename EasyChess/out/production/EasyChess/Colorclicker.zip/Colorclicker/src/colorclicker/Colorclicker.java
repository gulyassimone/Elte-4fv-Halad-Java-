package colorclicker;

public class Colorclicker {

    public static void main(String[] args) {
        ColorClickerGUI gui = new ColorClickerGUI();
    }

}
