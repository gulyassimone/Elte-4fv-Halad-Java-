export const WaitingRoomData = [
  {
    id: 275,
    ownerName: "Levike",
    ownerId: 28,
    spaces: 5,
    full: false,
    joinedPlayers: [
      { name: "Ferike", id: 27 },
      { name: "Apa", id: 26 },
      { name: "Sanyika", id: 32 },
    ],
  },
  {
    id: 276,
    ownerName: "Gergőke",
    ownerId: 29,
    spaces: 5,
    full: false,
    joinedPlayers: [{ name: "Lili", id: 33 }],
  },
  {
    id: 277,
    ownerName: "Anya",
    ownerId: 31,
    spaces: 4,
    full: false,
    joinedPlayers: [
      { name: "Mami", id: 34 },
      { name: "Dédi", id: 35 },
    ],
  },
  {
    id: 278,
    ownerName: "Valaki",
    ownerId: 38,
    spaces: 3,
    full: true,
    joinedPlayers: [
      { name: "Egyik", id: 36 },
      { name: "Másik", id: 37 },
    ],
  },
  {
    id: 279,
    ownerName: "MásValaki",
    ownerId: 55,
    spaces: 4,
    full: false,
    joinedPlayers: [
      { name: "Egyiksem", id: 56 },
      { name: "Másiksem", id: 57 },
    ],
  },
];
