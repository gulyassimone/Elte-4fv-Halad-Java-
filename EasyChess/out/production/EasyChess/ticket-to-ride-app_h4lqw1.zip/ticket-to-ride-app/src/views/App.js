import { Home } from "./home/Home";
import { Layout } from "./layout/Layout";
import { WaitingRoom } from "./waitingroom/WaitingRoom";
import { Game } from "./game/Game";
import {
  BrowserRouter,
  Route,
  Switch,
} from "../../node_modules/react-router-dom/umd/react-router-dom";
import "../views/App.css";

export function App() {
  return (
    <BrowserRouter>
      <Layout>
        <Switch>
          <Route exact path="/">
            <Home />
          </Route>
          <Route path="/waitingroom">
            <WaitingRoom />
          </Route>
          <Route path="/game">
            <Game />
          </Route>
        </Switch>
      </Layout>
    </BrowserRouter>
  );
}
