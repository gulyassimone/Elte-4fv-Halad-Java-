//import blackCard from "../../assets/cards/black_card.jpg";
import blueCard from "../../assets/cards/blue_card.jpg";
//import brownCard from "../../assets/cards/brown_card.jpg";
//import draw from "../../assets/cards/draw.jpg";
import greenCard from "../../assets/cards/green_card.jpg";
import locomotive from "../../assets/cards/locomotive_card.jpg";
import longTicket from "../../assets/cards/long_ticket.jpg";
//import purpleCard from "../../assets/cards/purple_card.jpg";
import redCard from "../../assets/cards/red_card.jpg";
//import scoring from "../../assets/cards/scoring.jpg";
import shortTicket from "../../assets/cards/short_ticket.jpg";
//import whiteCard from "../../assets/cards/white_card.jpg";
import yellowCard from "../../assets/cards/yellow_card.jpg";

import rBlackCard from "../../assets/cards/rotated/black_card.jpg";
import rBlueCard from "../../assets/cards/rotated/blue_card.jpg";
import rBrownCard from "../../assets/cards/rotated/brown_card.jpg";
import rDraw from "../../assets/cards/rotated/draw.jpg";
//import rGreenCard from "../../assets/cards/rotated/green_card.jpg";
import rLocomotive from "../../assets/cards/rotated/locomotive_card.jpg";
//import rPurpleCard from "../../assets/cards/rotated/purple_card.jpg";
//import rRedCard from "../../assets/cards/rotated/red_card.jpg";
import rShortTicket from "../../assets/cards/rotated/short_ticket.jpg";
//import rWhiteCard from "../../assets/cards/rotated/white_card.jpg";
//import rYellowCard from "../../assets/cards/rotated/yellow_card.jpg";
import map from "../../assets/map.jpg";
import "./game.css";

export function Game() {
  return (
    <div className="ui three column padded grid">
      <div className="three wide column">
        <p>Active Player: Levike</p>
        <div className="ui list">
          <div className="item">
            <i className="blue user icon"></i>
            <div className="content">
              <div className="header">
                <div className="texttype">Levike</div>
              </div>
              <div className="description texttype">
                <b>1</b>. player 18 pt
              </div>
            </div>
          </div>
          <div className="item">
            <i className="blue user icon"></i>
            <div className="content">
              <div className="header">
                <div className="texttype">Ferike</div>
              </div>
              <div className="description texttype">
                <b>2</b>. player 5 pt
              </div>
            </div>
          </div>
          <div className="item">
            <i className="blue user icon"></i>
            <div className="content">
              <div className="header">
                <div className="texttype">Apa</div>
              </div>
              <div className="description texttype">
                <b>3</b>. player 10 pt
              </div>
            </div>
          </div>
          <div className="item">
            <i className="blue user icon"></i>
            <div className="content">
              <div className="header">
                <div className="texttype">Sanyika</div>
              </div>
              <div className="description texttype">
                <b>4</b>. player 25 pt
              </div>
            </div>
          </div>
          <div className="item">
            <i className="blue user icon"></i>
            <div className="content">
              <div className="header">
                <div className="texttype">Sanyika</div>
              </div>
              <div className="description texttype">
                <b>5</b>. player 13 pt
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="ten wide column">
        <div className="row">
          <div className="ui grid">
            <div className="two wide column">
              <div className="row gamecard rowspace">
                <img src={rBlueCard} alt="blue" />
              </div>
              <div className="row gamecard rowspace">
                <img src={rBrownCard} alt="brown" />
              </div>
              <div className="row gamecard rowspace">
                <img src={rBlackCard} alt="black" />
              </div>
              <div className="row gamecard rowspace">
                <img className="lococard" src={rLocomotive} alt="loco" />
              </div>
              <div className="row gamecard rowspace">
                <img src={rBlackCard} alt="black" />
              </div>
              <div className="row gamecard rowspace"></div>
              <div className="row gamecard rowspace">
                <img className="drawcard" src={rDraw} alt="draw" />
              </div>
              <div className="row gamecard rowspace">
                <img className="drawcard" src={rShortTicket} alt="drawticket" />
              </div>
            </div>
            <div className="fourteen wide column">
              <div style={{ position: "relative" }}>
                <img className="gameboard" src={map} alt="" />
                <map name="infographic"></map>
                <div
                  style={{
                    position: "absolute",
                    display: "block",
                    top: "8.818011257035648%",
                    left: "16.5%",
                    width: "10px",
                    height: "10px",
                    backgroundColor: "red",
                  }}
                ></div>
                <div
                  style={{
                    position: "absolute",
                    display: "block",
                    top: "30.58161350844278%",
                    left: "31.874999999999996%",
                    width: "10px",
                    height: "10px",
                    backgroundColor: "red",
                  }}
                ></div>
                <div
                  style={{
                    position: "absolute",
                    display: "block",
                    top: "54.409005628517825%",
                    left: "59.12500000000001%",
                    width: "10px",
                    height: "10px",
                    backgroundColor: "red",
                  }}
                ></div>
                <div
                  style={{
                    position: "absolute",
                    display: "block",
                    top: "89.8686679174484%",
                    left: "85.625%",
                    width: "10px",
                    height: "10px",
                    backgroundColor: "red",
                  }}
                ></div>
              </div>
            </div>
          </div>
        </div>
        <div className="row">
          <div className="ui nine column padded grid container">
            <div className="column gamecard">
              <img src={blueCard} alt="blue" />
              <div className="cardtext">2</div>
            </div>
            <div className="column gamecard">
              <img src={yellowCard} alt="yellow" />
              <div className="cardtext">1</div>
            </div>
            <div className="column gamecard">
              <img src={greenCard} alt="green" />
              <div className="cardtext">4</div>
            </div>
            <div className="column gamecard">
              <img className="lococard" src={locomotive} alt="loco" />
              <div className="cardtext">1</div>
            </div>
            <div className="column gamecard">
              <img src={redCard} alt="red" />
              <div className="cardtext">5</div>
            </div>
          </div>
        </div>
      </div>
      <div className="three wide column">
        <div className="ui two column padded grid">
          <div className="gamecard column">
            <img className="ticket" src={shortTicket} alt="ticket" />
            <div className="destinationtext">
              Budapest
              <br />
              Sofia
              <br />5 pt
            </div>
          </div>
          <div className="gamecard column">
            <img className="ticket" src={shortTicket} alt="ticket" />
            <div className="destinationtext">
              Rostov
              <br />
              Erzurum
              <br />5 pt
            </div>
          </div>
          <div className="gamecard column">
            <img className="ticket" src={longTicket} alt="ticket" />
            <div className="destinationtext">
              Rostov
              <br />
              Erzurum
              <br />
              20 pt
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
