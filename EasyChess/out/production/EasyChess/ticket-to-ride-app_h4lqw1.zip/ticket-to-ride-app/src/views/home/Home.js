import "./home.css";
import Title from "../../assets/title.png";
import Box from "../../assets/box.png";
import Rules from "../../domain/Rules.pdf";
import { NavLink } from "../../../node_modules/react-router-dom/umd/react-router-dom";
import { HostJoin } from "./HostJoin";
import { Rooms } from "./Rooms";
import { WaitingRoomData } from "../../domain/waitingroom";

export function Home() {
  const allRooms = WaitingRoomData;
  return (
    <div className="ui three column stackable grid">
      <div className="three wide column"></div>
      <div className="ten wide column">
        <div className="ui center aligned container">
          <img className="title" src={Title} alt="title" />
          <h1>Europe</h1>
          <div className="ui two column doubling stackable grid container">
            <div className="column">
              <p>
                From the craggy hillsides of Edinburgh to the sunlit docks of
                Constantinople, from the dusty alleys of Pamplona to a windswept
                station in Berlin, Ticket to Ride Europe takes you on an
                exciting train adventure through the great cities of
                turn-of-the-century Europe.
              </p>
            </div>
            <div className="column">
              <div className="ui one column doubling stackable grid container">
                <div className="column">
                  <img className="box" src={Box} alt="Box" />
                </div>
                <div className="column">
                  <NavLink
                    className="ui pink button"
                    to={Rules}
                    target="_blank"
                  >
                    Game rules
                  </NavLink>
                </div>
              </div>
            </div>
          </div>
          <HostJoin />
        </div>
      </div>
      <Rooms rooms={allRooms} />
    </div>
  );
}
