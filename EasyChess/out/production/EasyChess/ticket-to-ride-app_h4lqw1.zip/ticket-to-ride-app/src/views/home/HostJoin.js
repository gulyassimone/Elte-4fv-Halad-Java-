import { useState } from "react";

function Field({ label, placeholder, name, value, onChange, type }) {
  return (
    <div className="field">
      <label>{label}</label>
      <div className="ui left icon input">
        <input
          name={name}
          value={value}
          type={type}
          onChange={(e) =>
            type === "number"
              ? onChange(
                  name,
                  isNaN(parseInt(e.target.value))
                    ? ""
                    : parseInt(e.target.value)
                )
              : onChange(name, e.target.value)
          }
          placeholder={placeholder}
        />
        <i className="users icon"></i>
      </div>
    </div>
  );
}

const hostDefaultState = {
  numOfPlayers: "",
  name: "",
};

const joinDefaultState = {
  id: "",
  name: "",
};

export function HostJoin() {
  const [joinState, setJoinState] = useState(joinDefaultState);
  const [hostState, setHostState] = useState(hostDefaultState);

  const handleJoinFieldChange = (name, value) => {
    setJoinState({ ...joinState, [name]: value });
  };

  const handleHostFieldChange = (name, value) => {
    setHostState({ ...hostState, [name]: value });
  };

  return (
    <div className="ui segment">
      <div className="ui two column very relaxed stackable grid">
        <div className="column">
          <h2>Host game</h2>
          <form className="ui form">
            <Field
              value={hostState.numOfPlayers}
              name="numOfPlayers"
              label="Number of players (min 2, max 5)"
              placeholder="Number of players"
              type="number"
              onChange={handleHostFieldChange}
            />
            <Field
              value={hostState.name}
              name="name"
              label="Player's name"
              placeholder="Name"
              type="text"
              onChange={handleHostFieldChange}
            />
            <div className="ui green submit button">Start</div>
          </form>
        </div>

        <div className="middle aligned column">
          <h2>Join game</h2>
          <form className="ui form">
            <Field
              value={joinState.id}
              name="id"
              label="Room ID"
              placeholder="Room ID"
              type="number"
              onChange={handleJoinFieldChange}
            />
            <Field
              value={joinState.name}
              name="name"
              label="Player's name"
              placeholder="Name"
              type="text"
              onChange={handleJoinFieldChange}
            />
            <div className="ui blue submit button">Join</div>
          </form>
        </div>
      </div>
    </div>
  );
}
