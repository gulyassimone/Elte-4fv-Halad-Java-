export function Rooms({ rooms }) {
  return !rooms.length ? (
    true
  ) : (
    <div className="three wide column">
      <p>Available Rooms</p>
      <div className="ui container">
        <div className="ui list">
          {rooms.map((room) =>
            room.spaces - (room.joinedPlayers.length + 1) === 0 ? (
              ""
            ) : (
              <div className="item" key={room.id}>
                <i className="blue user icon"></i>
                <div className="content">
                  <div className="header">
                    <div className="texttype">{room.ownerName}'s room</div>
                  </div>
                  <div className="description texttype">
                    Number of free spaces{" "}
                    <b>{room.spaces - (room.joinedPlayers.length + 1)}</b>/
                    {room.spaces}. <br />
                    Room ID:
                    <b>{room.id}</b>
                  </div>
                </div>
              </div>
            )
          )}
        </div>
      </div>
    </div>
  );
}
