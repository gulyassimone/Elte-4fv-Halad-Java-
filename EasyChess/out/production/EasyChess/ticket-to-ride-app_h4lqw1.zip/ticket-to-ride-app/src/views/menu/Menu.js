import { NavLink } from "../../../node_modules/react-router-dom/umd/react-router-dom";

export function Menu() {
  return (
    <nav className="ui three item stackable menu">
      <NavLink className="item" exact to="/">
        <i className="circular inverted black home icon"></i> Home
      </NavLink>
      <NavLink className="item" to="/waitingroom">
        <i className="circular inverted black users icon"></i> Waiting for orher
        players
      </NavLink>
      <NavLink className="item" to="/game">
        <i className="circular inverted black train icon"></i> Game
      </NavLink>
    </nav>
  );
}
