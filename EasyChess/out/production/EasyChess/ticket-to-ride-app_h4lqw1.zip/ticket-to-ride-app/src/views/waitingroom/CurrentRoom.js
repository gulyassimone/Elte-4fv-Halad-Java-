export function CurrentRoom({ players, space }) {
  return !players.length ? (
    true
  ) : (
    <div className="ui grid">
      <div className="six wide column"></div>
      <div className="four wide column">
        <div className="ui container">
          <div className="ui list">
            {players.map((player, index) => (
              <div className="item" key={player.id}>
                <i className="blue user icon"></i>
                <div className="content">
                  <div className="header">
                    <div className="texttype">
                      {player.name} Id:{player.id}
                    </div>
                  </div>
                  <div className="description texttype">
                    <b>{index + 2}</b>. player / {space}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
      <div className="six wide column"></div>
    </div>
  );
}
