import "./MovingLoco.css";

export function MovingLoco() {
  return (
    <div id="circle">
      <div id="content">
        <div className="sky">
          <div className="sun"></div>
        </div>
        <div className="loco">
          <div className="compartment">
            <div className="chimney">
              <div id="steam" className="steam1"></div>
              <div id="steam" className="steam2"></div>
              <div id="steam" className="steam3"></div>
              <div id="steam" className="steam4"></div>
            </div>
          </div>
          <div className="compartment1"></div>
        </div>
        <div className="bridge">
          <div className="bridge1"></div>
        </div>
        <div className="mountains">
          <div className="mountain1"></div>
          <div className="mountain2"></div>
        </div>
      </div>
    </div>
  );
}
