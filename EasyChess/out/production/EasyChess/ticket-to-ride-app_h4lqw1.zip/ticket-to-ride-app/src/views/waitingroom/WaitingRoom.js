import { MovingLoco } from "./MovingLoco";
import { CurrentRoom } from "./CurrentRoom";
import { WaitingRoomData } from "../../domain/waitingroom.js";

export function WaitingRoom() {
  const selectedRoom = WaitingRoomData[0];
  console.log(selectedRoom);
  return (
    <div className="ui center aligned container">
      <p>
        {selectedRoom.ownerName}'s room Waiting for other players ...
        <br />
        Room ID: {selectedRoom.id}
      </p>
      <MovingLoco />

      <p>Players already joined</p>
      <CurrentRoom
        players={selectedRoom.joinedPlayers}
        space={selectedRoom.spaces}
      />
    </div>
  );
}
